function [f, J] = fjbowtie(x,p,u,b, varargin)

if ~isempty(varargin)
    t = varargin{1};
    f = eval_f3(x,p,u,b, t);
    J = FiniteDifferenceJacobian_t(@eval_f3, x, p, u, b, t);
else 
    f = eval_f3(x,p,u,b);
    J = FiniteDifferenceJacobian_t(@eval_f3, x, p, u, b);
end 

